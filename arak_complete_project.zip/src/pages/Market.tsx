import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, PieChart as PieChartIcon, DollarSign, Target, BarChart3, Globe } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { PageWrapper, Section, Badge, SectionHeading } from '../components/Shared';

const sectorData = [
  { name: 'Oil & Gas', value: 45, color: '#00dfd8' },
  { name: 'Power & Energy', value: 30, color: '#0070f3' },
  { name: 'Manufacturing', value: 15, color: '#ff00ff' },
  { name: 'Water & Utilities', value: 10, color: '#ffffff' },
];

const growthData = [
  { year: '2024', market: 22.5 },
  { year: '2025', market: 25.8 },
  { year: '2026', market: 29.4 },
  { year: '2027', market: 33.6 },
  { year: '2028', market: 38.4 },
  { year: '2029', market: 43.8 },
  { year: '2030', market: 50.0 },
];

export const MarketPage = () => (
  <PageWrapper>
    <Section>
      <SectionHeading 
        badge="Market Analysis"
        title="The $32.3B Opportunity"
        subtitle="The global pipeline inspection and repair market is witnessing unprecedented growth due to aging infrastructure."
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
        {[
          { icon: <Globe />, label: "TAM (Global)", value: "$32.3B", desc: "Total Addressable Market for industrial robotics." },
          { icon: <Target />, label: "SAM (Serviceable)", value: "$12.8B", desc: "Focused on Oil & Gas and Power sectors." },
          { icon: <TrendingUp />, label: "CAGR", value: "14.2%", desc: "Projected annual growth through 2030." },
        ].map((stat, i) => (
          <div key={i} className="glass-card p-12 text-center tech-border group">
            <div className="w-16 h-16 rounded-2xl bg-brand-cyan/5 flex items-center justify-center text-brand-cyan mx-auto mb-8 group-hover:scale-110 transition-transform">
              {stat.icon}
            </div>
            <p className="text-[10px] text-white/30 uppercase tracking-[0.3em] mb-4 font-bold">{stat.label}</p>
            <p className="text-5xl font-black mb-6 tracking-tighter">{stat.value}</p>
            <p className="text-sm text-white/40 leading-relaxed font-light">{stat.desc}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-32">
        <div className="glass-card p-12">
          <h3 className="text-3xl font-black uppercase tracking-tighter mb-12">Sector Distribution</h3>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} opacity={0.8} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#050505', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-6 mt-8">
            {sectorData.map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-white/60 uppercase tracking-widest font-bold">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-12">
          <h3 className="text-3xl font-black uppercase tracking-tighter mb-12">Market Growth Projection</h3>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={growthData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis 
                  dataKey="year" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
                />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  contentStyle={{ backgroundColor: '#050505', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                />
                <Bar dataKey="market" fill="#00dfd8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-center text-[10px] text-white/20 uppercase tracking-[0.2em] mt-8">Values in Billion USD</p>
        </div>
      </div>

      <div className="glass-card p-16 relative overflow-hidden mb-32">
        <div className="scanline" />
        <div className="relative z-10">
          <Badge>Business Model</Badge>
          <h3 className="text-5xl font-black uppercase tracking-tighter mb-12">Revenue Streams</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              { title: "IaaS", full: "Inspection-as-a-Service", desc: "Subscription-based regular monitoring for industrial plants." },
              { title: "Hardware", full: "Unit Sales", desc: "One-time sales of UV-resin modules and robot units." },
              { title: "Analytics", full: "Data Insights", desc: "Predictive maintenance reports powered by our AI cloud." },
              { title: "Compliance", full: "Safety Audits", desc: "Certification and safety audits for government agencies." },
            ].map((item, i) => (
              <div key={i} className="group">
                <p className="text-4xl font-black text-brand-cyan mb-4 group-hover:scale-110 transition-transform origin-left">{item.title}</p>
                <h4 className="font-bold mb-2 uppercase text-xs tracking-widest">{item.full}</h4>
                <p className="text-sm text-white/30 leading-relaxed font-light">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  </PageWrapper>
);
