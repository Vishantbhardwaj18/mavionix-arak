import React from 'react';
import { motion } from 'motion/react';
import { Cpu, Zap, Search, Wrench, ShieldAlert, Activity, CheckCircle2, Layers, Code, Settings, Terminal } from 'lucide-react';
import { PageWrapper, Section, Badge, SectionHeading, Reveal } from '../components/Shared';

export const TechnologyPage = () => (
  <PageWrapper>
    <Section>
      <Reveal width="100%">
        <SectionHeading 
          badge="Technical Architecture"
          title="Engineering the Future"
          subtitle="ARAK-1 is built on a modular, high-reliability framework designed for extreme industrial environments."
          variant="violet"
        />
      </Reveal>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-32">
        <Reveal className="lg:col-span-2" width="100%">
          <div className="glass-card p-8 md:p-12 tech-border group bg-brand-slate/10 h-full relative overflow-hidden">
            <div className="scanline" />
            <div className="flex flex-col sm:flex-row justify-between items-start gap-6 mb-12">
              <div>
                <h3 className="text-4xl font-black uppercase tracking-tighter mb-2">Hardware Stack</h3>
                <p className="text-brand-cyan font-mono text-xs uppercase tracking-widest">System Revision 1.0.4</p>
              </div>
              <Settings className="text-brand-cyan w-10 h-10 animate-spin-slow" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
              {[
                { label: "Control Center", value: "Raspberry Pi 4B", desc: "Main processing unit for AI and high-level logic.", color: "brand-cyan" },
                { label: "Locomotion Controller", value: "Arduino Mega 2560", desc: "Real-time control for 12+ servos and motors.", color: "brand-violet" },
                { label: "Visual System", value: "ESP32-CAM", desc: "Low-latency video streaming and image capture.", color: "brand-emerald" },
                { label: "Sensing Array", value: "MQ-Series Sensors", desc: "Detection of CO, LPG, Smoke, and Methane.", color: "brand-amber" },
                { label: "Actuators", value: "SG90 Servos", desc: "High-torque articulated leg movement.", color: "brand-magenta" },
                { label: "Power System", value: "Li-Po 11.1V", desc: "High-density energy for extended missions.", color: "brand-cyan" },
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + (i * 0.1) }}
                  className="group/item"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className={`text-[10px] text-${item.color} uppercase tracking-widest font-bold`}>{item.label}</span>
                    <div className="h-[1px] flex-1 mx-4 bg-white/10 group-hover/item:bg-white/20 transition-colors" />
                  </div>
                  <p className="text-xl font-bold mb-2 uppercase">{item.value}</p>
                  <p className="text-sm text-white/30 leading-relaxed font-light">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="space-y-8">
          <Reveal width="100%">
            <div className="glass-card p-8 border-brand-magenta/20 hover:border-brand-magenta/50 transition-colors bg-brand-magenta/5">
              <h3 className="text-2xl font-bold mb-8 flex items-center gap-4 uppercase">
                <Code className="text-brand-magenta" /> Software
              </h3>
              <div className="space-y-8">
                {[
                  { label: "Core Language", value: "Python 3.x", color: "brand-magenta" },
                  { label: "Computer Vision", value: "OpenCV", color: "brand-violet" },
                  { label: "Robot OS", value: "ROS", color: "brand-cyan" },
                  { label: "Simulation", value: "Gazebo", color: "brand-emerald" },
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + (i * 0.1) }}
                  >
                    <p className={`text-[10px] text-${item.color} uppercase tracking-widest mb-1 font-bold`}>{item.label}</p>
                    <p className="text-lg font-bold uppercase">{item.value}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </Reveal>
          
          <Reveal width="100%" delay={0.2}>
            <div className="glass-card p-8 bg-brand-cyan/5 border-brand-cyan/20">
              <h4 className="font-bold mb-4 uppercase tracking-widest text-xs text-brand-cyan">System Diagnostics</h4>
              <div className="space-y-4">
                {[
                  { label: "Logic Unit", val: 85, color: "bg-brand-cyan" },
                  { label: "Motor Array", val: 92, color: "bg-brand-violet" },
                  { label: "Sensor Grid", val: 78, color: "bg-brand-amber" },
                  { label: "Vision Core", val: 95, color: "bg-brand-emerald" }
                ].map((item, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-[10px] mb-1 uppercase text-white/40">
                      <span>{item.label}</span>
                      <span>{item.val}%</span>
                    </div>
                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.val}%` }}
                        transition={{ duration: 1.5, delay: 0.5 + (i * 0.1), ease: "easeOut" }}
                        className={`h-full ${item.color}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      <Reveal width="100%">
        <SectionHeading 
          badge="Innovation"
          title="UV Repair Mechanism"
          subtitle="Our proprietary emergency sealing system allows for immediate intervention without human entry."
          center
          variant="emerald"
        />
      </Reveal>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
        {[
          { step: "01", title: "Defect Detection", desc: "AI identifies a crack or leak using the onboard camera and gas sensors.", color: "brand-cyan" },
          { step: "02", title: "Resin Injection", desc: "A specialized polymer resin is precisely applied to the damaged area.", color: "brand-violet" },
          { step: "03", title: "UV Curing", desc: "High-intensity UV LEDs cure the resin in seconds, creating a durable seal.", color: "brand-emerald" },
        ].map((item, i) => (
          <Reveal key={i} delay={i * 0.2} width="100%">
            <div className="glass-card p-12 text-center relative group hover:bg-white/5 transition-colors overflow-hidden h-full">
              <div className={`text-8xl font-black text-white/[0.02] absolute top-4 left-1/2 -translate-x-1/2 group-hover:text-${item.color}/[0.05] transition-colors`}>
                {item.step}
              </div>
              <div className={`w-16 h-16 rounded-2xl bg-${item.color}/5 flex items-center justify-center text-${item.color} mx-auto mb-8 group-hover:scale-110 transition-transform`}>
                {i === 0 ? <Search /> : i === 1 ? <Zap /> : <Wrench />}
              </div>
              <h4 className="text-2xl font-bold mb-4 relative z-10 uppercase tracking-tight">{item.title}</h4>
              <p className="text-white/40 leading-relaxed relative z-10 font-light">{item.desc}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal width="100%">
        <div className="glass-card p-8 md:p-12 bg-brand-slate/20 border border-white/5">
          <h3 className="text-3xl font-black mb-12 text-center uppercase tracking-tighter">Competitive Analysis</h3>
          <div className="overflow-x-auto -mx-8 md:mx-0">
            <table className="w-full text-left border-collapse min-w-[800px]">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="py-6 px-6 text-xs uppercase tracking-widest text-white/40">Feature</th>
                  <th className="py-6 px-6 text-xs uppercase tracking-widest text-brand-cyan">ARAK-1</th>
                  <th className="py-6 px-6 text-xs uppercase tracking-widest text-white/40">CUES Inc</th>
                  <th className="py-6 px-6 text-xs uppercase tracking-widest text-white/40">Deep Trekker</th>
                  <th className="py-6 px-6 text-xs uppercase tracking-widest text-white/40">Solinas</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {[
                  { feature: "Locomotion", arak: "Hybrid Spider-Wheel", cues: "Wheeled", deep: "Tracked", solinas: "Wheeled" },
                  { feature: "Repair Mechanism", arak: "UV Curing Resin", cues: "None", deep: "None", solinas: "None" },
                  { feature: "Gas Sensing", arak: "Multi-Gas Array", cues: "Optional", deep: "Limited", solinas: "Basic" },
                  { feature: "AI Detection", arak: "Real-time Edge AI", cues: "Post-Processing", deep: "Manual", solinas: "Basic" },
                  { feature: "Cost Effectiveness", arak: "High (Low Capex)", cues: "Low (High Capex)", deep: "Medium", solinas: "Medium" },
                ].map((row, i) => (
                  <motion.tr 
                    key={i} 
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors"
                  >
                    <td className="py-6 px-6 font-medium uppercase tracking-tight text-white/60">{row.feature}</td>
                    <td className="py-6 px-6 text-brand-cyan font-bold uppercase">{row.arak}</td>
                    <td className="py-6 px-6 text-white/30">{row.cues}</td>
                    <td className="py-6 px-6 text-white/30">{row.deep}</td>
                    <td className="py-6 px-6 text-white/30">{row.solinas}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Reveal>
    </Section>
  </PageWrapper>
);
