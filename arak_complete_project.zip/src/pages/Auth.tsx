import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, ShieldCheck, Mail, Lock, Building2, ArrowRight } from 'lucide-react';
import { PageWrapper, Section, Badge } from '../components/Shared';

export const AuthPage = () => {
  const [isLogin, setIsLogin] = React.useState(true);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, we would validate credentials here
    localStorage.setItem('arak_auth', 'true');
    navigate('/dashboard');
  };

  return (
    <PageWrapper className="flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-brand-magenta/10 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-brand-cyan/10 blur-[120px] rounded-full animate-pulse" />
      </div>
      
      <div className="w-full max-w-md">
        <div className="text-center mb-12">
          <Badge variant={isLogin ? "cyan" : "magenta"}>ARAK Control Room</Badge>
          <h2 className="text-5xl font-black uppercase tracking-tighter mb-4">
            {isLogin ? "Access Portal" : "New Operator"}
          </h2>
          <p className="text-white/40 text-sm font-light">Secure authentication required for remote robot control.</p>
        </div>

        <div className="glass-card p-10 tech-border relative">
          <div className="scanline" />
          
          <div className="flex bg-white/5 p-1 rounded-lg mb-10">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-[0.2em] rounded-md transition-all ${isLogin ? 'bg-brand-cyan text-brand-dark' : 'text-white/40 hover:text-white'}`}
            >
              Login
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-[0.2em] rounded-md transition-all ${!isLogin ? 'bg-brand-magenta text-brand-dark' : 'text-white/40 hover:text-white'}`}
            >
              Register
            </button>
          </div>

          <form className="space-y-6" onSubmit={handleSubmit}>
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Organization Name</label>
                <div className="relative">
                  <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                  <input 
                    type="text" 
                    className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-6 py-4 focus:outline-none focus:border-brand-magenta transition-colors text-sm"
                    placeholder="Global Energy Corp"
                  />
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Operator ID / Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                <input 
                  type="email" 
                  className={`w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-6 py-4 focus:outline-none transition-colors text-sm ${isLogin ? 'focus:border-brand-cyan' : 'focus:border-brand-magenta'}`}
                  placeholder="operator@arak.io"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Access Key</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                <input 
                  type="password" 
                  className={`w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-6 py-4 focus:outline-none transition-colors text-sm ${isLogin ? 'focus:border-brand-cyan' : 'focus:border-brand-magenta'}`}
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button 
              type="submit" 
              className={`w-full py-4 rounded-lg font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-3 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg ${
                isLogin 
                  ? 'bg-brand-cyan text-brand-dark shadow-brand-cyan/20' 
                  : 'bg-brand-magenta text-brand-dark shadow-brand-magenta/20'
              }`}
            >
              {isLogin ? 'Initialize Session' : 'Create Account'}
              <ArrowRight className="w-5 h-5" />
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-center gap-4 text-[10px] uppercase tracking-widest text-white/20 font-bold">
            <ShieldCheck className="w-4 h-4" />
            256-Bit Encrypted Connection
          </div>
        </div>
      </div>
    </PageWrapper>
  );
};
