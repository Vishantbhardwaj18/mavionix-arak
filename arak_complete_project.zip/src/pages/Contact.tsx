import React from 'react';
import { motion } from 'motion/react';
import { Mail, Globe, MapPin, Send, MessageSquare, Phone, ShieldAlert } from 'lucide-react';
import { PageWrapper, Section, Badge, SectionHeading, Reveal } from '../components/Shared';

export const ContactPage = () => {
  const [formState, setFormState] = React.useState('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    setTimeout(() => setFormState('success'), 1500);
  };

  return (
    <PageWrapper>
      <Section>
        <Reveal width="100%">
          <SectionHeading 
            badge="Contact Us"
            title="Get in Touch"
            subtitle="Interested in ARAK-1? Our team is ready to discuss deployment, partnerships, or technical inquiries."
            variant="magenta"
          />
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
          <div className="space-y-8 md:space-y-12">
            <Reveal width="100%">
              <div className="glass-card p-8 md:p-12 tech-border bg-brand-slate/10 h-full">
                <h3 className="text-3xl font-black uppercase tracking-tighter mb-12">Contact Information</h3>
                <div className="space-y-10">
                  {[
                    { icon: <Mail />, label: "Email", value: "vishantbhardwaj06@gmail.com", color: "brand-cyan" },
                    { icon: <Globe />, label: "Website", value: "www.mavionix.com", color: "brand-violet" },
                    { icon: <MapPin />, label: "Location", value: "SRM IST, NCR Campus, Ghaziabad", color: "brand-emerald" },
                    { icon: <Phone />, label: "Emergency Support", value: "+91 98765 43210", color: "brand-amber" },
                  ].map((item, i) => (
                    <motion.div 
                      key={i} 
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + (i * 0.1) }}
                      className="flex gap-6 group"
                    >
                      <div className={`w-12 h-12 rounded-xl bg-${item.color}/5 flex items-center justify-center text-${item.color} group-hover:scale-110 transition-transform`}>
                        {item.icon}
                      </div>
                      <div>
                        <p className="text-[10px] text-white/30 uppercase tracking-widest mb-1 font-bold">{item.label}</p>
                        <p className={`text-lg font-bold group-hover:text-${item.color} transition-colors break-all md:break-normal`}>{item.value}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal width="100%" delay={0.4}>
              <div className="p-8 bg-brand-amber/5 border border-brand-amber/20 rounded-2xl flex gap-6 items-center group">
                <div className="w-12 h-12 rounded-full bg-brand-amber/10 flex items-center justify-center text-brand-amber shrink-0 animate-pulse group-hover:scale-110 transition-transform">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold uppercase text-brand-amber text-sm">Emergency Response</h4>
                  <p className="text-xs text-white/40 leading-relaxed">For critical infrastructure failure reports, please use our 24/7 priority line.</p>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal width="100%" delay={0.2}>
            <div className="glass-card p-8 md:p-12 relative overflow-hidden bg-brand-slate/5 h-full">
              <div className="scanline" />
              <h3 className="text-3xl font-black uppercase tracking-tighter mb-12">Send Message</h3>
              {formState === 'success' ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-24"
                >
                  <div className="w-20 h-20 bg-brand-emerald/20 rounded-full flex items-center justify-center mx-auto mb-8">
                    <Send className="text-brand-emerald w-10 h-10" />
                  </div>
                  <h4 className="text-3xl font-black uppercase tracking-tighter mb-4">Transmission Received</h4>
                  <p className="text-white/40 mb-12 font-light">Our team will respond to your inquiry within 24 standard hours.</p>
                  <button 
                    onClick={() => setFormState('idle')}
                    className="btn-secondary mx-auto text-xs uppercase tracking-widest px-10"
                  >
                    New Transmission
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Full Name</label>
                      <input 
                        type="text" 
                        required
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-6 py-4 focus:outline-none focus:border-brand-cyan transition-colors text-sm"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Email Address</label>
                      <input 
                        type="email" 
                        required
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-6 py-4 focus:outline-none focus:border-brand-cyan transition-colors text-sm"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Subject</label>
                    <div className="relative">
                      <select className="w-full bg-white/5 border border-white/10 rounded-lg px-6 py-4 focus:outline-none focus:border-brand-cyan transition-colors text-sm appearance-none cursor-pointer">
                        <option className="bg-brand-dark">Partnership Inquiry</option>
                        <option className="bg-brand-dark">Technical Support</option>
                        <option className="bg-brand-dark">Investor Relations</option>
                        <option className="bg-brand-dark">Other</option>
                      </select>
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-white/20">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Message</label>
                    <textarea 
                      required
                      rows={4}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-6 py-4 focus:outline-none focus:border-brand-cyan transition-colors text-sm resize-none"
                      placeholder="How can we help you?"
                    />
                  </div>
                  
                  <button 
                    type="submit" 
                    disabled={formState !== 'idle'}
                    className="btn-primary w-full justify-center group py-5"
                  >
                    {formState === 'idle' && (
                      <>Send Message <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" /></>
                    )}
                    {formState === 'submitting' && (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-brand-dark/30 border-t-brand-dark rounded-full animate-spin" />
                        Processing...
                      </span>
                    )}
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </Section>
    </PageWrapper>
  );
};
