import React from 'react';
import { Users, Globe, Layers, CheckCircle2 } from 'lucide-react';
import { PageWrapper, Section, Badge, SectionHeading } from '../components/Shared';

export const AboutPage = () => (
  <PageWrapper>
    <Section>
      <SectionHeading 
        badge="Our Story"
        title="MaVionix Team"
        subtitle="A dedicated team of engineers from SRM Institute of Science & Technology, NCR Campus, pushing the boundaries of Cyber-Physical Systems."
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center mb-32">
        <div className="space-y-8">
          <h3 className="text-4xl font-black uppercase tracking-tighter">The Vision</h3>
          <p className="text-xl text-white/40 leading-relaxed font-light">
            Born out of the need for safer industrial maintenance, MaVionix focuses on 
            integrating AI-driven detection with immediate repair capabilities.
          </p>
          <div className="space-y-6">
            <p className="text-white/60 leading-relaxed">
              We believe that robotics should not just observe, but actively protect. 
              Our flagship project, ARAK-1, represents the first step towards a 
              fully autonomous infrastructure health network.
            </p>
            <div className="flex gap-12 pt-6">
              <div>
                <p className="text-5xl font-black text-brand-cyan tracking-tighter">TRL 4-5</p>
                <p className="text-[10px] text-white/30 uppercase tracking-widest mt-2 font-bold">Readiness Level</p>
              </div>
              <div>
                <p className="text-5xl font-black text-brand-magenta tracking-tighter">2026</p>
                <p className="text-[10px] text-white/30 uppercase tracking-widest mt-2 font-bold">Project Launch</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {[
            { name: "Vishant Bhardwaj", role: "Team Leader", img: "vishant", color: "cyan" },
            { name: "Maanya Tyagi", role: "Full Stack Dev", img: "maanya", color: "magenta" },
          ].map((member, i) => (
            <div key={i} className="glass-card p-8 tech-border group">
              <div className="w-full aspect-square rounded-xl bg-white/5 mb-6 overflow-hidden relative">
                <img 
                  src={`https://picsum.photos/seed/${member.img}/400/400`} 
                  alt={member.name} 
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700 grayscale group-hover:grayscale-0" 
                  referrerPolicy="no-referrer" 
                />
                <div className={`absolute inset-0 bg-brand-${member.color}/20 opacity-0 group-hover:opacity-100 transition-opacity`} />
              </div>
              <h4 className="text-xl font-black uppercase tracking-tight">{member.name}</h4>
              <p className={`text-[10px] uppercase tracking-widest font-bold text-brand-${member.color}`}>{member.role}</p>
            </div>
          ))}
          <div className="glass-card p-8 col-span-full flex items-center gap-6 bg-white/[0.02]">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center shrink-0">
              <Users className="text-white/40" />
            </div>
            <div>
              <h4 className="text-lg font-bold uppercase">Dr. Rolly Gupta</h4>
              <p className="text-xs text-white/40 uppercase tracking-widest">Project Mentor • Assistant Professor, SRM IST</p>
            </div>
          </div>
        </div>
      </div>

      <SectionHeading 
        badge="Evolution"
        title="ARAK Roadmap"
        center
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-32">
        {[
          { id: "ARAK-1", title: "Emergency Sealing", desc: "First-gen inspection and temporary repair using UV curing." },
          { id: "ARAK-2", title: "Autonomous Repair", desc: "Advanced AI-based defect restoration and permanent patching." },
          { id: "ARAK-3", title: "Swarm Network", desc: "Coordinated multi-robot inspection for large-scale networks." },
          { id: "ARAK-X", title: "National System", desc: "Continuous infrastructure health monitoring across the country." },
        ].map((step, i) => (
          <div key={i} className="glass-card p-10 border-b-4 border-brand-cyan relative overflow-hidden group hover:-translate-y-2 transition-transform">
            <div className="scanline" />
            <p className="text-brand-cyan font-mono text-[10px] mb-6 font-bold tracking-widest">{step.id}</p>
            <h4 className="text-2xl font-black uppercase tracking-tighter mb-4 group-hover:text-brand-cyan transition-colors">{step.title}</h4>
            <p className="text-white/30 text-sm leading-relaxed font-light">{step.desc}</p>
          </div>
        ))}
      </div>
    </Section>

    <Section className="bg-white/[0.02]">
      <div className="max-w-5xl mx-auto">
        <h3 className="text-3xl font-bold mb-12 text-center">Project Recognition</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass-card p-8 flex items-center gap-6">
            <div className="w-16 h-16 bg-brand-cyan/10 rounded-xl flex items-center justify-center shrink-0">
              <Globe className="text-brand-cyan" />
            </div>
            <div>
              <h4 className="font-bold text-xl mb-2">THRUST Tech Expo 2026</h4>
              <p className="text-sm text-white/50">Organized by Indian Institute of Technology Hyderabad (IITH).</p>
            </div>
          </div>
          <div className="glass-card p-8 flex items-center gap-6">
            <div className="w-16 h-16 bg-brand-magenta/10 rounded-xl flex items-center justify-center shrink-0">
              <Layers className="text-brand-magenta" />
            </div>
            <div>
              <h4 className="font-bold text-xl mb-2">India Innovates 2026</h4>
              <p className="text-sm text-white/50">Municipal Corporation of Delhi (MCD) Innovation Showcase.</p>
            </div>
          </div>
        </div>
      </div>
    </Section>
  </PageWrapper>
);
