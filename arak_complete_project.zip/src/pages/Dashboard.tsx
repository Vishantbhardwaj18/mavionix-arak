import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  History, 
  Settings, 
  Activity, 
  Battery, 
  MapPin, 
  ShieldCheck, 
  Zap, 
  ArrowUpRight,
  Filter,
  Search,
  ShoppingCart,
  CheckCircle2,
  AlertCircle,
  X,
  LogOut,
  Bot
} from 'lucide-react';
import { PageWrapper, Section, Badge, Reveal } from '../components/Shared';
import { useNavigate } from 'react-router-dom';

const FLEET_DATA = [
// ... existing data ...
  {
    id: "ARAK-1-ALPHA",
    status: "Available",
    health: 98,
    battery: 100,
    location: "Sector 7G",
    price: 250,
    image: "https://picsum.photos/seed/robot1/400/400",
    specs: ["UV Repair", "Gas Sensing", "4K Vision"]
  },
  {
    id: "ARAK-1-BRAVO",
    status: "Rented",
    health: 85,
    battery: 42,
    location: "Pipeline B-12",
    price: 250,
    image: "https://picsum.photos/seed/robot2/400/400",
    specs: ["Heavy Duty", "Thermal Imaging", "Extended Range"]
  },
  {
    id: "ARAK-1-CHARLIE",
    status: "Maintenance",
    health: 62,
    battery: 12,
    location: "Central Hub",
    price: 250,
    image: "https://picsum.photos/seed/robot3/400/400",
    specs: ["Compact", "Fast Scan", "IoT Mesh"]
  },
  {
    id: "ARAK-1-DELTA",
    status: "Available",
    health: 100,
    battery: 100,
    location: "Sector 4A",
    price: 280,
    image: "https://picsum.photos/seed/robot4/400/400",
    specs: ["Reinforced", "Deep Sea", "AI Core v2"]
  }
];

export const DashboardPage = () => {
  const [activeTab, setActiveTab] = React.useState('marketplace');
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedUnit, setSelectedUnit] = React.useState<any>(null);
  const [isRenting, setIsRenting] = React.useState(false);
  const [rentSuccess, setRentSuccess] = React.useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('arak_auth');
    navigate('/');
  };

  const handleRent = () => {
    setIsRenting(true);
    setTimeout(() => {
      setIsRenting(false);
      setRentSuccess(true);
      setTimeout(() => {
        setRentSuccess(false);
        setSelectedUnit(null);
      }, 2000);
    }, 1500);
  };

  return (
    <PageWrapper className="min-h-screen flex">
      {/* Fixed Sidebar */}
      <aside className="w-72 fixed inset-y-0 left-0 bg-brand-dark/40 backdrop-blur-xl border-r border-white/10 p-8 flex flex-col z-50">
        <div className="flex items-center gap-3 mb-12 px-2">
          <div className="relative">
            <Bot className="text-brand-cyan w-8 h-8" />
            <div className="absolute inset-0 bg-brand-cyan/20 blur-lg rounded-full animate-pulse" />
          </div>
          <span className="text-2xl font-display font-black tracking-tighter uppercase">MAVIONIX</span>
        </div>

        <div className="mb-8 px-2">
          <h2 className="text-xl font-black uppercase tracking-tighter">Command Center</h2>
          <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold">Operator Dashboard</p>
        </div>
        
        <nav className="flex-1 space-y-2">
          {[
            { id: 'overview', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
            { id: 'marketplace', label: 'Marketplace', icon: <ShoppingBag className="w-4 h-4" /> },
            { id: 'rentals', label: 'My Rentals', icon: <History className="w-4 h-4" /> },
            { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? 'bg-brand-cyan text-brand-dark font-bold shadow-lg shadow-brand-cyan/20' 
                  : 'text-white/40 hover:bg-white/5 hover:text-white'
              }`}
            >
              {item.icon}
              <span className="text-xs uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="pt-8 mt-8 border-t border-white/5">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all text-white/40 hover:bg-brand-magenta/10 hover:text-brand-magenta group"
          >
            <LogOut className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            <span className="text-xs uppercase tracking-widest font-bold">Exit Portal</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 ml-72 p-12 overflow-y-auto bg-brand-dark">
        <div className="max-w-6xl mx-auto">
          
          {/* Unit Detail Modal */}
          <AnimatePresence>
            {selectedUnit && (
              <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setSelectedUnit(null)}
                  className="absolute inset-0 bg-brand-dark/80 backdrop-blur-md"
                />
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 20 }}
                  className="relative w-full max-w-4xl glass-card overflow-hidden tech-border bg-brand-dark"
                >
                  <div className="scanline" />
                  <div className="flex flex-col md:flex-row">
                    <div className="md:w-1/2 h-64 md:h-auto relative">
                      <img 
                        src={selectedUnit.image} 
                        alt={selectedUnit.id} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-transparent to-transparent" />
                    </div>
                    <div className="md:w-1/2 p-8 md:p-12">
                      <div className="flex justify-between items-start mb-6">
                        <div>
                          <Badge variant="cyan">{selectedUnit.status}</Badge>
                          <h3 className="text-4xl font-black uppercase tracking-tighter mt-2">{selectedUnit.id}</h3>
                        </div>
                        <button 
                          onClick={() => setSelectedUnit(null)}
                          className="p-2 hover:bg-white/5 rounded-full transition-colors"
                        >
                          <X className="w-6 h-6 text-white/40" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-8 mb-8">
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-2">Technical Health</p>
                          <div className="flex items-center gap-3">
                            <Activity className="w-5 h-5 text-brand-emerald" />
                            <span className="text-2xl font-black">{selectedUnit.health}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-2">Energy Level</p>
                          <div className="flex items-center gap-3">
                            <Battery className="w-5 h-5 text-brand-cyan" />
                            <span className="text-2xl font-black">{selectedUnit.battery}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4 mb-8">
                        <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Integrated Modules</p>
                        <div className="flex flex-wrap gap-2">
                          {selectedUnit.specs.map((s: string) => (
                            <span key={s} className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] uppercase tracking-widest font-bold text-brand-cyan">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="p-6 bg-white/5 rounded-2xl border border-white/10 mb-8">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Rental Rate</p>
                            <p className="text-3xl font-black text-brand-cyan">${selectedUnit.price}<span className="text-xs text-white/40 font-light">/day</span></p>
                          </div>
                          <button 
                            onClick={handleRent}
                            disabled={isRenting || rentSuccess}
                            className={`btn-primary px-8 py-4 text-xs tracking-[0.2em] min-w-[160px] ${
                              rentSuccess ? 'bg-brand-emerald text-white' : ''
                            }`}
                          >
                            {isRenting ? (
                              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}>
                                <Zap className="w-4 h-4" />
                              </motion.div>
                            ) : rentSuccess ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              'Confirm Rental'
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Live Telemetry Preview</p>
                        <div className="h-24 bg-black/40 rounded-xl border border-white/5 flex items-center justify-center relative overflow-hidden">
                          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent)', backgroundSize: '20px 20px' }} />
                          <motion.div 
                            animate={{ opacity: [0.2, 0.5, 0.2] }}
                            transition={{ duration: 2, repeat: Infinity }}
                            className="text-[8px] uppercase tracking-[0.3em] font-bold text-brand-cyan"
                          >
                            Waiting for secure handshake...
                          </motion.div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* Header Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                { label: "Active Units", value: "12", icon: <Zap className="text-brand-cyan" /> },
                { label: "Total Revenue", value: "$14,250", icon: <Activity className="text-brand-emerald" /> },
                { label: "System Health", value: "94%", icon: <ShieldCheck className="text-brand-violet" /> },
                { label: "Active Alerts", value: "2", icon: <AlertCircle className="text-brand-amber" /> },
              ].map((stat, i) => (
                <Reveal key={i} delay={i * 0.1}>
                  <div className="glass-card p-6 bg-white/5 border-white/10">
                    <div className="flex justify-between items-start mb-4">
                      <div className="p-2 bg-white/5 rounded-lg">{stat.icon}</div>
                      <ArrowUpRight className="w-4 h-4 text-white/20" />
                    </div>
                    <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold mb-1">{stat.label}</p>
                    <p className="text-2xl font-black">{stat.value}</p>
                  </div>
                </Reveal>
              ))}
            </div>

            {/* Marketplace View */}
            {activeTab === 'marketplace' && (
              <div className="space-y-8">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="relative w-full sm:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                    <input 
                      type="text"
                      placeholder="Search fleet..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-6 py-3 focus:outline-none focus:border-brand-cyan transition-colors text-sm"
                    />
                  </div>
                  <button className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-xs uppercase tracking-widest font-bold hover:bg-white/10 transition-all">
                    <Filter className="w-4 h-4" /> Filter
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {FLEET_DATA.filter(unit => unit.id.toLowerCase().includes(searchQuery.toLowerCase())).map((unit, i) => (
                    <Reveal key={unit.id} delay={i * 0.1}>
                      <div 
                        onClick={() => setSelectedUnit(unit)}
                        className="glass-card overflow-hidden group border-white/10 hover:border-brand-cyan/50 transition-all cursor-pointer"
                      >
                        <div className="relative h-48 overflow-hidden">
                          <img 
                            src={unit.image} 
                            alt={unit.id} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-60 group-hover:opacity-100"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute top-4 right-4">
                            <Badge variant={
                              unit.status === 'Available' ? 'emerald' : 
                              unit.status === 'Rented' ? 'violet' : 'amber'
                            }>
                              {unit.status}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="p-6">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h3 className="text-xl font-black uppercase tracking-tighter">{unit.id}</h3>
                              <div className="flex items-center gap-2 text-[10px] text-white/40 uppercase tracking-widest font-bold">
                                <MapPin className="w-3 h-3" /> {unit.location}
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-brand-cyan font-black text-xl">${unit.price}</p>
                              <p className="text-[8px] text-white/40 uppercase tracking-widest">Per 24h Cycle</p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="space-y-1">
                              <div className="flex justify-between text-[8px] uppercase tracking-widest text-white/40 font-bold">
                                <span>Health</span>
                                <span>{unit.health}%</span>
                              </div>
                              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                <div className="h-full bg-brand-emerald" style={{ width: `${unit.health}%` }} />
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-[8px] uppercase tracking-widest text-white/40 font-bold">
                                <span>Battery</span>
                                <span>{unit.battery}%</span>
                              </div>
                              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                <div className="h-full bg-brand-cyan" style={{ width: `${unit.battery}%` }} />
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2 mb-6">
                            {unit.specs.map((spec, idx) => (
                              <span key={idx} className="text-[8px] uppercase tracking-widest px-2 py-1 bg-white/5 border border-white/10 rounded-md text-white/60">
                                {spec}
                              </span>
                            ))}
                          </div>

                          <button 
                            disabled={unit.status !== 'Available'}
                            className={`w-full py-3 rounded-xl font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all ${
                              unit.status === 'Available' 
                                ? 'bg-brand-cyan text-brand-dark hover:scale-[1.02] active:scale-[0.98]' 
                                : 'bg-white/5 text-white/20 cursor-not-allowed'
                            }`}
                          >
                            <ShoppingCart className="w-4 h-4" />
                            {unit.status === 'Available' ? 'Initialize Rental' : 'Unit Unavailable'}
                          </button>
                        </div>
                      </div>
                    </Reveal>
                  ))}
                </div>
              </div>
            )}

            {/* Overview View (Smart Enhancement) */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 glass-card p-8 bg-brand-slate/20 tech-border relative overflow-hidden">
                    <div className="scanline" />
                    <h3 className="text-xl font-black uppercase tracking-tighter mb-8">Active Deployment Map</h3>
                    <div className="aspect-video bg-white/5 rounded-2xl relative overflow-hidden border border-white/10">
                      {/* Mock Map UI */}
                      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
                      <motion.div 
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                        transition={{ duration: 3, repeat: Infinity }}
                        className="absolute top-1/3 left-1/4 w-4 h-4 bg-brand-cyan rounded-full blur-sm" 
                      />
                      <motion.div 
                        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                        transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                        className="absolute bottom-1/4 right-1/3 w-4 h-4 bg-brand-magenta rounded-full blur-sm" 
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <p className="text-[10px] uppercase tracking-[0.4em] text-white/20 font-bold">Satellite Feed Offline</p>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card p-8 bg-white/5 border-white/10">
                    <h3 className="text-xl font-black uppercase tracking-tighter mb-8">Recent Activity</h3>
                    <div className="space-y-6">
                      {[
                        { type: 'rental', msg: 'ARAK-1-ALPHA rental initialized', time: '2m ago', icon: <CheckCircle2 className="text-brand-emerald" /> },
                        { type: 'alert', msg: 'ARAK-1-BRAVO battery low', time: '15m ago', icon: <AlertCircle className="text-brand-amber" /> },
                        { type: 'system', msg: 'Firmware update complete', time: '1h ago', icon: <Zap className="text-brand-cyan" /> },
                        { type: 'rental', msg: 'ARAK-1-CHARLIE returned', time: '3h ago', icon: <History className="text-brand-violet" /> },
                      ].map((log, i) => (
                        <div key={i} className="flex gap-4">
                          <div className="mt-1">{log.icon}</div>
                          <div>
                            <p className="text-xs font-bold uppercase tracking-tight">{log.msg}</p>
                            <p className="text-[10px] text-white/30 uppercase tracking-widest">{log.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="glass-card p-8 bg-white/5 border-white/10">
                  <h3 className="text-xl font-black uppercase tracking-tighter mb-8">Fleet Performance Analytics</h3>
                  <div className="h-48 flex items-end gap-2">
                    {[40, 70, 45, 90, 65, 80, 50, 85, 60, 75, 95, 55].map((h, i) => (
                      <motion.div
                        key={i}
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        transition={{ delay: i * 0.05, duration: 1 }}
                        className="flex-1 bg-gradient-to-t from-brand-cyan/20 to-brand-cyan rounded-t-sm"
                      />
                    ))}
                  </div>
                  <div className="flex justify-between mt-4 text-[8px] uppercase tracking-widest text-white/40 font-bold">
                    <span>Jan</span>
                    <span>Feb</span>
                    <span>Mar</span>
                    <span>Apr</span>
                    <span>May</span>
                    <span>Jun</span>
                    <span>Jul</span>
                    <span>Aug</span>
                    <span>Sep</span>
                    <span>Oct</span>
                    <span>Nov</span>
                    <span>Dec</span>
                  </div>
                </div>
              </div>
            )}

            {/* Placeholder for other tabs */}
            {(activeTab === 'rentals' || activeTab === 'settings') && (
              <div className="glass-card p-20 text-center border-white/10">
                <LayoutDashboard className="w-12 h-12 text-white/10 mx-auto mb-6" />
                <h3 className="text-xl font-black uppercase tracking-tighter mb-2">{activeTab} Interface</h3>
                <p className="text-white/40 text-sm font-light">This module is currently under maintenance or restricted access.</p>
              </div>
            )}
          </div>
        </main>
      </PageWrapper>
    );
  };
