import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Activity, ShieldAlert, Cpu, AlertTriangle, CheckCircle2, Zap, Search, Wrench } from 'lucide-react';
import { PageWrapper, Section, Badge, SectionHeading, Reveal } from '../components/Shared';

export const HomePage = () => (
  <PageWrapper>
    <Section className="min-h-[90vh] flex flex-col justify-center relative pt-32">
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.15, 0.1]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-brand-violet/10 blur-[150px] rounded-full" 
        />
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.05, 0.1, 0.05]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-brand-cyan/5 blur-[150px] rounded-full" 
        />
      </div>
      
      <div className="max-w-6xl">
        <Reveal>
          <Badge variant="emerald">System Status: Operational</Badge>
        </Reveal>
        
        <Reveal delay={0.2}>
          <h1 className="text-[clamp(4rem,15vw,12rem)] font-black mb-4 leading-[0.8] tracking-tighter uppercase">
            ARAK-1
          </h1>
        </Reveal>

        <Reveal delay={0.4}>
          <div className="flex items-center gap-4 mb-12">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "6rem" }}
              transition={{ duration: 1, delay: 0.6 }}
              className="h-[2px] bg-brand-cyan" 
            />
            <p className="text-xl md:text-3xl text-brand-cyan font-bold uppercase tracking-widest font-display">
              Autonomous Quadruped Monitoring
            </p>
          </div>
        </Reveal>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-end">
          <Reveal delay={0.6}>
            <div>
              <p className="text-lg md:text-xl text-white/50 mb-12 leading-relaxed font-light max-w-xl">
                Redefining industrial safety through spider-inspired robotics. 
                ARAK-1 navigates complex pipeline networks to detect and repair 
                critical failures in real-time.
              </p>
              <div className="flex flex-wrap gap-6">
                <Link to="/contact" className="btn-primary group px-10">
                  Request Demo <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link to="/technology" className="btn-secondary px-10">
                  Technical Specs
                </Link>
              </div>
            </div>
          </Reveal>
          
          <Reveal delay={0.8} width="100%">
            <div className="glass-card p-8 tech-border bg-brand-slate/20 relative overflow-hidden group">
              <div className="scanline" />
              <div className="flex justify-between items-center mb-6">
                <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Live Telemetry</span>
                <span className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-brand-emerald font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-brand-emerald animate-ping" />
                  Active Session
                </span>
              </div>
              <div className="space-y-4 font-mono text-[11px]">
                {[
                  { label: 'CPU LOAD', value: '24.5%', color: 'text-brand-cyan' },
                  { label: 'GAS SENSOR', value: 'NOMINAL', color: 'text-brand-emerald' },
                  { label: 'BATTERY', value: '88%', color: 'text-brand-cyan' },
                  { label: 'TEMP', value: '42°C', color: 'text-brand-amber' },
                  { label: 'UPTIME', value: '124:12:05', color: 'text-white' },
                ].map((stat, i) => (
                  <motion.div 
                    key={i} 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 1 + (i * 0.1) }}
                    className="flex justify-between border-b border-white/5 pb-2"
                  >
                    <span className="text-white/30">{stat.label}</span>
                    <span className={stat.color}>{stat.value}</span>
                  </motion.div>
                ))}
              </div>
              <div className="mt-6 flex gap-1 h-8 items-end">
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ height: [10, Math.random() * 30 + 10, 10] }}
                    transition={{ duration: 1, repeat: Infinity, delay: i * 0.05 }}
                    className="flex-1 bg-brand-cyan/20 rounded-t-sm"
                  />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </Section>

    <Section className="bg-white/[0.01] border-y border-white/5">
      <Reveal width="100%">
        <SectionHeading 
          badge="The Problem"
          title="Infrastructure at Risk"
          subtitle="Global energy networks are aging. Manual inspection is no longer sufficient for modern safety standards."
          variant="amber"
        />
      </Reveal>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
        <div className="space-y-12">
          {[
            { title: "Human Safety Risks", desc: "Exposure to toxic gases and high-pressure environments causes thousands of injuries annually.", color: "brand-amber" },
            { title: "Limited Mobility", desc: "Traditional wheeled robots struggle with curved or uneven surfaces in complex pipeline junctions.", color: "brand-magenta" },
            { title: "Economic Loss", desc: "Unscheduled shutdowns for manual repair lead to massive production downtime and revenue loss.", color: "brand-violet" },
          ].map((item, i) => (
            <Reveal key={i} delay={i * 0.2} width="100%">
              <div className="group">
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-10 h-10 rounded bg-${item.color}/10 flex items-center justify-center text-${item.color} group-hover:scale-110 transition-transform`}>
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <h4 className="text-2xl font-bold uppercase tracking-tight">{item.title}</h4>
                </div>
                <p className="text-white/40 leading-relaxed pl-14">{item.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={0.4} width="100%">
          <div className="relative">
            <div className="glass-card p-2 tech-border group overflow-hidden">
              <img src="https://picsum.photos/seed/pipeline/1200/800" alt="Pipeline" className="rounded-xl opacity-40 grayscale group-hover:grayscale-0 group-hover:opacity-80 group-hover:scale-105 transition-all duration-1000" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <motion.div 
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="p-6 bg-brand-amber/10 border border-brand-amber/30 rounded-lg backdrop-blur-xl"
                >
                  <p className="text-brand-amber font-black uppercase tracking-[0.3em] text-sm">Critical Failure Zone</p>
                </motion.div>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-brand-amber/20 blur-3xl rounded-full animate-pulse" />
          </div>
        </Reveal>
      </div>
    </Section>

    <Section>
      <Reveal width="100%">
        <SectionHeading 
          badge="The Solution"
          title="ARAK-1 Capabilities"
          subtitle="Detect + Repair in a single deployment. Our spider-inspired robot navigates where others fail."
          center
          variant="emerald"
        />
      </Reveal>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { icon: <Zap />, title: "Hybrid Locomotion", desc: "Spider-like articulated legs combined with wheels for maximum adaptability.", color: "brand-cyan" },
          { icon: <Search />, title: "AI Detection", desc: "Onboard computer vision identifies cracks and corrosion in real-time.", color: "brand-violet" },
          { icon: <Wrench />, title: "Instant Repair", desc: "UV-curing polymer patch system for immediate emergency sealing.", color: "brand-emerald" },
          { icon: <Activity />, title: "IoT Dashboard", desc: "Live sensor data and video feed transmitted to remote monitoring stations.", color: "brand-cyan" },
          { icon: <ShieldAlert />, title: "Gas Monitoring", desc: "MQ-series sensors detect hazardous leaks before they become disasters.", color: "brand-amber" },
          { icon: <CheckCircle2 />, title: "Autonomous Mode", desc: "Intelligent path planning and obstacle avoidance for independent operation.", color: "brand-magenta" }
        ].map((item, i) => (
          <Reveal key={i} delay={i * 0.1} width="100%">
            <div className="glass-card p-8 hover:bg-white/5 transition-all group h-full">
              <div className={`w-12 h-12 rounded-lg bg-${item.color}/10 flex items-center justify-center text-${item.color} mb-6 group-hover:scale-110 transition-transform`}>
                {item.icon}
              </div>
              <h4 className="text-xl font-bold mb-4 uppercase tracking-tight">{item.title}</h4>
              <p className="text-white/40 text-sm leading-relaxed font-light">{item.desc}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>

    <Section className="bg-brand-violet/5 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand-violet/50 to-transparent" />
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <Reveal width="100%">
          <div className="flex flex-col items-center">
            <Badge variant="violet">Impact Analysis</Badge>
            <h2 className="text-4xl md:text-7xl font-black mb-16 uppercase tracking-tighter">Redefining Industrial Safety</h2>
          </div>
        </Reveal>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-12">
          {[
            { value: "90%", label: "Risk Reduction", color: "text-brand-cyan" },
            { value: "60%", label: "Cost Savings", color: "text-brand-magenta" },
            { value: "24/7", label: "Monitoring", color: "text-brand-emerald" }
          ].map((stat, i) => (
            <Reveal key={i} delay={i * 0.2} width="100%">
              <div>
                <motion.p 
                  initial={{ scale: 0.5, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 100, delay: i * 0.2 }}
                  className={`text-6xl font-black ${stat.color} mb-2`}
                >
                  {stat.value}
                </motion.p>
                <p className="text-white/30 uppercase text-[10px] font-bold tracking-[0.2em]">{stat.label}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </Section>
  </PageWrapper>
);
