import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, LogIn, Menu, X, Mail, Globe, LayoutDashboard } from 'lucide-react';

export const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const location = useLocation();

  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    
    // Check auth state
    const checkAuth = () => {
      const authStatus = localStorage.getItem('arak_auth') === 'true';
      setIsLoggedIn(authStatus);
    };
    
    checkAuth();
    window.addEventListener('storage', checkAuth);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('storage', checkAuth);
    };
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Technology', path: '/technology' },
    { name: 'Market', path: '/market' },
    { name: 'Contact', path: '/contact' },
  ];

  if (isLoggedIn) {
    navLinks.push({ name: 'Dashboard', path: '/dashboard' });
  }

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'py-4' : 'py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className={`relative flex justify-between items-center px-6 py-3 rounded-2xl transition-all duration-500 ${scrolled ? 'bg-brand-dark/40 backdrop-blur-xl border border-white/10 shadow-2xl' : ''}`}>
          <Link to="/" className="flex items-center gap-3 group relative z-50">
            <div className="relative">
              <Bot className="text-brand-cyan w-8 h-8 group-hover:rotate-12 transition-transform" />
              <div className="absolute inset-0 bg-brand-cyan/20 blur-lg rounded-full animate-pulse" />
            </div>
            <span className="text-2xl font-display font-black tracking-tighter uppercase">MAVIONIX</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                className={`text-[10px] font-bold uppercase tracking-[0.2em] transition-all hover:text-brand-cyan relative group ${location.pathname === link.path ? 'text-brand-cyan' : 'text-white/40'}`}
              >
                {link.name}
                <span className={`absolute -bottom-1 left-0 h-px bg-brand-cyan transition-all duration-300 ${location.pathname === link.path ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </Link>
            ))}
            {isLoggedIn ? (
              <Link to="/dashboard" className="btn-primary py-2 px-6 text-[10px] tracking-[0.2em] shadow-none hover:shadow-brand-cyan/20">
                <LayoutDashboard className="w-4 h-4" /> Dashboard
              </Link>
            ) : (
              <Link to="/auth" className="btn-primary py-2 px-6 text-[10px] tracking-[0.2em] shadow-none hover:shadow-brand-cyan/20">
                <LogIn className="w-4 h-4" /> Portal
              </Link>
            )}
          </div>

          {/* Mobile Toggle */}
          <button 
            className="md:hidden relative z-50 p-2 text-white/60 hover:text-brand-cyan transition-colors" 
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-40 bg-brand-dark/95 backdrop-blur-2xl md:hidden flex flex-col items-center justify-center gap-8"
          >
            <div className="absolute inset-0 -z-10 overflow-hidden">
              <div className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-brand-cyan/10 blur-[120px] rounded-full" />
              <div className="absolute bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-brand-magenta/10 blur-[120px] rounded-full" />
            </div>
            
            {navLinks.map((link, i) => (
              <motion.div
                key={link.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Link 
                  to={link.path} 
                  onClick={() => setIsOpen(false)}
                  className={`text-4xl font-black uppercase tracking-tighter transition-all ${location.pathname === link.path ? 'text-brand-cyan' : 'text-white/40 hover:text-white'}`}
                >
                  {link.name}
                </Link>
              </motion.div>
            ))}
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: navLinks.length * 0.1 }}
              className="mt-8"
            >
              {isLoggedIn ? (
                <Link 
                  to="/dashboard" 
                  onClick={() => setIsOpen(false)}
                  className="btn-primary px-12 py-4 text-xs tracking-[0.2em]"
                >
                  Go to Dashboard
                </Link>
              ) : (
                <Link 
                  to="/auth" 
                  onClick={() => setIsOpen(false)}
                  className="btn-primary px-12 py-4 text-xs tracking-[0.2em]"
                >
                  Access Portal
                </Link>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Footer = () => (
  <footer className="py-12 px-6 md:px-24 border-t border-white/10 bg-brand-dark relative overflow-hidden">
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-brand-cyan/50 to-transparent" />
    <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
      <div className="col-span-1 md:col-span-2">
        <div className="flex items-center gap-3 mb-6">
          <Bot className="text-brand-cyan w-8 h-8" />
          <span className="text-2xl font-display font-bold tracking-tighter">MAVIONIX</span>
        </div>
        <p className="text-white/50 max-w-sm mb-6">
          Pioneering autonomous robotics for critical infrastructure monitoring and emergency repair. 
          "If a place is dangerous for a human to enter first, a machine should go first."
        </p>
        <div className="flex gap-4">
          <Link to="/contact" className="p-2 rounded-full bg-white/5 border border-white/10 hover:border-brand-cyan transition-colors">
            <Mail className="w-5 h-5" />
          </Link>
          <a href="#" className="p-2 rounded-full bg-white/5 border border-white/10 hover:border-brand-cyan transition-colors">
            <Globe className="w-5 h-5" />
          </a>
        </div>
      </div>
      <div>
        <h4 className="font-bold mb-6 uppercase tracking-widest text-xs text-brand-cyan">Quick Links</h4>
        <ul className="space-y-4 text-sm text-white/40">
          <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
          <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
          <li><Link to="/technology" className="hover:text-white transition-colors">Technology</Link></li>
          <li><Link to="/market" className="hover:text-white transition-colors">Market Analysis</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="font-bold mb-6 uppercase tracking-widest text-xs text-brand-cyan">Contact</h4>
        <ul className="space-y-4 text-sm text-white/40">
          <li className="flex items-center gap-2"><Mail className="w-4 h-4" /> contact@mavionix.com</li>
          <li className="flex items-center gap-2"><Globe className="w-4 h-4" /> SRM IST, NCR Campus</li>
          <li>Ghaziabad, UP, India</li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6 pt-12 border-t border-white/5">
      <p className="text-white/20 text-xs">© 2026 MaVionix Robotics. All rights reserved.</p>
      <div className="flex gap-8 text-xs text-white/20">
        <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
        <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
      </div>
    </div>
  </footer>
);
