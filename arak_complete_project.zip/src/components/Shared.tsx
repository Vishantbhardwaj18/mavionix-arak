import React from 'react';
import { motion } from 'motion/react';

export const PageWrapper = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.5 }}
    className={`min-h-screen pt-24 ${className}`}
  >
    {children}
  </motion.div>
);

export const Section = ({ id, className = "", children }: { id?: string; className?: string; children: React.ReactNode }) => (
  <section id={id} className={`py-24 px-6 md:px-12 lg:px-24 overflow-hidden ${className}`}>
    {children}
  </section>
);

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  width?: "fit-content" | "100%";
  className?: string;
  key?: React.Key;
}

export const Reveal = ({ children, delay = 0, width = "fit-content", className = "" }: RevealProps) => (
  <div style={{ position: "relative", width, overflow: "hidden" }} className={className}>
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 75 },
        visible: { opacity: 1, y: 0 },
      }}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      {children}
    </motion.div>
  </div>
);

export const Badge = ({ children, variant = "cyan" }: { children: React.ReactNode; variant?: "cyan" | "magenta" | "emerald" | "amber" | "violet" }) => {
  const variants = {
    cyan: "bg-brand-cyan/5 text-brand-cyan border-brand-cyan/20",
    magenta: "bg-brand-magenta/5 text-brand-magenta border-brand-magenta/20",
    emerald: "bg-brand-emerald/5 text-brand-emerald border-brand-emerald/20",
    amber: "bg-brand-amber/5 text-brand-amber border-brand-amber/20",
    violet: "bg-brand-violet/5 text-brand-violet border-brand-violet/20",
  };
  
  const dots = {
    cyan: "bg-brand-cyan",
    magenta: "bg-brand-magenta",
    emerald: "bg-brand-emerald",
    amber: "bg-brand-amber",
    violet: "bg-brand-violet",
  };

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] mb-6 border ${variants[variant]}`}>
      <span className={`w-1 h-1 rounded-full mr-2 animate-pulse ${dots[variant]}`} />
      {children}
    </span>
  );
};

export const SectionHeading = ({ title, subtitle, badge, center = false, variant = "cyan" }: { title: string; subtitle?: string; badge?: string; center?: boolean; variant?: "cyan" | "magenta" | "emerald" | "amber" | "violet" }) => (
  <div className={`mb-20 ${center ? 'text-center mx-auto max-w-4xl' : ''}`}>
    {badge && <Badge variant={variant}>{badge}</Badge>}
    <h2 className="text-5xl md:text-7xl font-black mb-8 leading-[0.9] tracking-tighter uppercase">{title}</h2>
    {subtitle && <p className="text-xl text-white/40 leading-relaxed max-w-2xl font-light">{subtitle}</p>}
  </div>
);
